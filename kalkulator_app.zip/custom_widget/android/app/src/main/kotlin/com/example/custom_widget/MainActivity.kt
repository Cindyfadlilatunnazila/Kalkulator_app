package com.example.custom_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
