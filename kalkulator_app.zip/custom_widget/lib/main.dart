import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Calculator',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(title: 'Calculator'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _input = '';
  String _result = '';

  void _handleButtonPressed(String buttonText) {
    if (buttonText == 'C') {
      setState(() {
        _input = '';
        _result = '';
      });
    } else if (buttonText == '=') {
      try {
        final result = evalExpression(_input);
        setState(() {
          _result = result;
        });
      } catch (e) {
        setState(() {
          _result = 'Error';
        });
      }
    } else if (buttonText == 'backspace') {
      if (_input.isNotEmpty) {
        setState(() {
          _input = _input.substring(0, _input.length - 1);
        });
      }
    } else {
      setState(() {
        _input += buttonText;
      });
    }
  }

  String evalExpression(String input) {
    try {
      final parser = Parser();
      final expression = parser.parse(input);
      final context = ContextModel();
      final result = expression.evaluate(EvaluationType.REAL, context);

      return result.toString();
    } catch (e) {
      return 'Error';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  _input.isNotEmpty ? _input : '0',
                  style: Theme.of(context)
                      .textTheme
                      .displaySmall!
                      .copyWith(color: Colors.green),
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  _result.isNotEmpty ? _result : '0',
                  style: Theme.of(context)
                      .textTheme
                      .displaySmall!
                      .copyWith(color: Colors.green),
                ),
              ),
            ),
          ),
          GridView.count(
            padding: const EdgeInsets.all(10),
            shrinkWrap: true,
            crossAxisCount: 5,
            children: [
              for (var buttonText in [
                'C',
                '+/-',
                '%',
                'back',
                '7',
                '8',
                '9',
                '/',
                '4',
                '5',
                '6',
                'X',
                '1',
                '2',
                '3',
                '-',
                '0',
                '.',
                '=',
                '+',
              ])
                CalculatorButton(
                  backgroundColor: Theme.of(context).primaryColorLight,
                  foregroundColor: Theme.of(context).primaryColorDark,
                  text: buttonText,
                  onPressed: _handleButtonPressed,
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class CalculatorButton extends StatelessWidget {
  const CalculatorButton({
    Key? key,
    required this.backgroundColor,
    required this.foregroundColor,
    required this.text,
    required this.onPressed,
  }) : super(key: key);

  final Color backgroundColor;
  final Color foregroundColor;
  final String text;
  final void Function(String) onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onPressed(text);
      },
      child: Container(
        color: backgroundColor,
        child: Center(
          child: text == 'backspace'
              ? Icon(
                  Icons.backspace,
                  color: foregroundColor,
                )
              : Text(
                  text,
                  style: Theme.of(context)
                      .textTheme
                      .headlineMedium!
                      .copyWith(color: foregroundColor),
                ),
        ),
      ),
    );
  }
}
// Nama : Cindy Fadli Latun Nazila
// NIM : 12201790
